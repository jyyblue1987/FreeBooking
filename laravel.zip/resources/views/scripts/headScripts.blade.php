
<script src="{{ URL::asset('/') }}js/plugins/vendors.js"></script>

<script src="{{ URL::asset('/') }}js/plugins/plugins.js"></script>
<script src="{{ URL::asset('/') }}js/flow/ng-flow-standalone.min.js"></script>
<script src="{{ URL::asset('/') }}js/plugins/app.js"></script>
<script src="{{ URL::asset('/') }}js/services/server.js"></script>

