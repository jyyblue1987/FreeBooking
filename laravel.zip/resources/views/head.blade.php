<meta content="UTF-8">
<meta name="token" id="token" value="{{ csrf_token() }}" >

<title>Project Flyer</title>


<link rel="stylesheet" href="{{ URL::asset('/') }}css/app.css">
<link rel="stylesheet" href="{{ URL::asset('/') }}css/fonts/awesome-fonts.css">
<link rel="stylesheet" href="{{ URL::asset('/') }}css/custom/custom.min.css">
<link rel="stylesheet" href="{{ URL::asset('/') }}css/libs/libs.css">