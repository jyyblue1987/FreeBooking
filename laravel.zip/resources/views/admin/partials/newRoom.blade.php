<div class="page page-form-wizard clearfix ng-scope" ng-controller="roomsController">
    <ol class="breadcrumb breadcrumb-small">
        <li>Your Hotel</li>
        <li class="active"><a href="#/hotels">Room Data</a></li>
    </ol>

        <div class="page-wrap panel panel-body">



            <div class="row">

                <div class="col-lg-12">

                    @include('admin.partials.roomForm')
                </div>

            </div>

        </div>
</div>
