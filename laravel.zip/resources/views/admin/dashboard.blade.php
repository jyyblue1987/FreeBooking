<!DOCTYPE   html>
<html lang="en">
<head>

    @include("head")



</head>
<body
        ng-app="app"
        id="app"
        class="app theme-zero" custom-page
        ng-class="{'layout-horizontal': isLayoutHorizontal}"
        ng-controller="AppCtrl"
        >

<header class="site-head clearfix"
        id="site-head"
        ng-controller="HeadCtrl"
        ng-include=" 'administrator/header' ">
    <!-- linked header (static) view -->
</header>


<div class="main-container clearfix">

    <aside class="nav-wrap"
           id="site-nav"
           ng-controller="NavCtrl"
           ng-include=" 'administrator/navigation' " custom-scrollbar>

    </aside>




    <div class="content-container" ng-class="{container: isLayoutHorizontal}"
         id="content" ng-view>
        <!-- content using routing -->
    </div>


    @include("footer")


</div>


@include("scripts.headScripts")

</body>

</html>