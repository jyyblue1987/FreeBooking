<div class="page page-dashboard-v1 clearfix" ng-controller="DashboardCtrl">

    <div class="dash-head clearfix">
        <div class="left">
            <h3 class="text-uppercase title text-normal">Dashboard</h3>
            <p class="small text-uppercase">Welcome admin</p>
        </div>
        <div class="right mt15">
            <button class="btn btn-primary text-uppercase btn-lg btn-rounded">Upload App</button>
        </div>
    </div>

    <div class="page-wrap">
        <!-- Mini box -->
        <div class="row">
            <div class="col-lg-3 col-xs-6">
                <div class="panel panel-default mb30 mini-box">
                    <div class="panel-body">
                        <div class="info left">
                            <h4 class="text-bold mb5 mt0">2.5K</h4>
                            <p class="text-uppercase">Revenue</p>
                        </div>
                        <div class="icon fa fa-btc bg-primary right"></div>
                    </div>
                    <div class="panel-footer panel-footer-sm clearfix bg-primary">
                        <span class="text-uppercase left">Last month</span>
                        <span class="right">-20%</span>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-xs-6">
                <div class="panel panel-default mb30 mini-box">
                    <div class="panel-body">
                        <div class="info left">
                            <h4 class="text-bold mb5 mt0">10K</h4>
                            <p class="text-uppercase">Downloads</p>
                        </div>
                        <div class="icon fa fa-cloud-download bg-info right"></div>
                    </div>
                    <div class="panel-footer panel-footer-sm clearfix bg-info">
                        <span class="text-uppercase left">Last month</span>
                        <span class="right">+5.4%</span>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-xs-6">
                <div class="panel panel-default mb30 mini-box">
                    <div class="panel-body">
                        <div class="info left">
                            <h4 class="text-bold mb5 mt0">15</h4>
                            <p class="text-uppercase">Uploads</p>
                        </div>
                        <div class="icon fa fa-cloud-upload bg-primary right"></div>
                    </div>
                    <div class="panel-footer panel-footer-sm clearfix bg-primary">
                        <span class="text-uppercase left">Today</span>
                        <span class="right">-10%</span>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-xs-6">
                <div class="panel panel-default mb30 mini-box">
                    <div class="panel-body">
                        <div class="info left">
                            <h4 class="text-bold mb5 mt0">8K</h4>
                            <p class="text-uppercase">Visitors</p>
                        </div>
                        <div class="icon fa fa-bicycle bg-info right"></div>
                    </div>
                    <div class="panel-footer panel-footer-sm clearfix bg-info">
                        <span class="text-uppercase left">Today</span>
                        <span class="right">+25.9%</span>
                    </div>
                </div>
            </div>
        </div>
        <!-- #end row -->


        <div class="row">
            <div class="col-lg-7">
                <div class="app-stats panel panel-lined mb30">
                    <div class="panel-heading"><i>App Statistics</i></div>
                    <div class="panel-body">
                        <div class="labels right">
                            <p class="small"><i class="fa fa-circle"></i>Earnings</p>
                            <p class="small"><i class="fa fa-circle"></i>Downloads</p>
                        </div>
                        <div class="mt15">
                            <chartist type="Line" data="linedata" tip="true" opts="lineopts" class="ct-octave"></chartist>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #end col -->

            <div class="col-lg-5">
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-xs-6">
                        <div class="social-widgets facebook mb30">
                            <span class="fa fa-facebook icon"></span>
                            <span class="data"><em>30K</em> Likes</span>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-6">
                        <div class="social-widgets twitter mb30">
                            <span class="fa fa-twitter icon"></span>
                            <span class="data"><em>3.6M</em> Followers</span>
                        </div>
                    </div>
                </div>
                <!-- #end inner row, social widgets -->
                <div class="row">
                    <div class="col-lg-6">
                        <div class="panel panel-lined mb30">
                            <div class="panel-body text-center">
                                <div easypiechart percent="serverpiepercent" options="serverpieoptions" class="easypiechart"><span>@{{serverpiepercent}}%</span></div>
                                <p class="text-uppercase small mt10 text-bold">Server Load</p>
                            </div>
                        </div>
                    </div>


                    <div class="col-lg-6">
                        <div class="panel panel-lined mb30">
                            <div class="panel-body text-center">
                                <div easypiechart percent="bouncepiepercent" options="serverpieoptions" class="easypiechart"><span>@{{bouncepiepercent}}%</span></div>
                                <p class="text-uppercase small mt10 text-bold">Bounce Rate</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- #end server load, bounce rate, inner row -->
            </div>
            <!-- #end col -->
        </div>
        <!-- #end row -->



        <div class="row">


            <div class="col-lg-6">
                <div class="panel panel-lined mb30 forecast-widget">
                    <div class="panel-body">
                        <div class="clearfix mb30">
                            <div class="left">
                                <div class="text-bold forecast-today text-center">
                                    <skycon icon="weathertoday.icon" size="weathertoday.size" color="@{{weathertoday.color}}"></skycon>
                                    &nbsp;<span>40&deg;</span>
                                </div>
                                <div class="current-day text-uppercase bg-info text-center small">TUESDAY, 24<sup class="text-lowercase">th </sup>Feb</div>
                            </div>

                            <div class="right mt10">
                                <p class="text-uppercase"><i class="fa fa-map-marker"></i>&nbsp;Toronto, Canada</p>
                                <p class="text-uppercase small right text-bold">Feels Cloudy</p>
                            </div>
                        </div>
                        <!-- forecast-details -->
                        <ul class="list-unstyled forecast-details clearfix">
                            <li class="col-md-6 col-sm-6 clearfix mb15" ng-repeat="detail in forecastDetails">
                                <span class="text-bold left">@{{detail.type}}</span>
                                <span class="right">@{{detail.value}}</span>
                            </li>
                        </ul>
                    </div>
                    <!-- #end panel-body -->

                    <!-- whole week forecast -->
                    <div class="forecast-week panel-footer bg-info">
                        <ul class="list-unstyled clearfix text-center">
                            <li class="col-sm-4 col-md-2 col-xs-4" ng-repeat="day in weatherweeks">
                                <div class="icon"><skycon icon="day.icon" size="day.size" color="@{{day.color}}"></skycon></div>
                                <p>@{{day.day}}</p>
                                <p>@{{day.temp}}&deg;C</p>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- #end panel -->
            </div>
            <!-- #end weather widget -->
        </div>
        <!-- #end row -->
    </div>
    <!-- #end page-wrap -->
</div>