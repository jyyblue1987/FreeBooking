<footer id="site-foot" class="site-foot clearfix">
    <p class="left">&copy; Copyright 2014 <strong>APPBOARD</strong>, All rights reserved.</p>
    <p class="right">v1.1</p>
</footer>